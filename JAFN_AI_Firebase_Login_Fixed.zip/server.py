import http.server
import json
import base64
import time
import mimetypes
import os
import urllib.error
import urllib.request
from pathlib import Path

_FIREBASE_ADMIN_APP = None

def verify_firebase_token(auth_header):
    """Verify Firebase ID tokens with Admin SDK when configured, or Google's public signing keys otherwise.

    A service-account private key is not required for signature/audience/issuer validation.
    Without it, token revocation checks are unavailable; expiry and signature are still verified.
    """
    if not auth_header or not auth_header.startswith("Bearer "):
        return None, (401, "Login dengan Google diperlukan.")
    token = auth_header[7:].strip()
    if not token:
        return None, (401, "Token login tidak ditemukan.")

    global _FIREBASE_ADMIN_APP
    project_id = os.environ.get("FIREBASE_PROJECT_ID", "jafn-ai").strip()
    raw = os.environ.get("FIREBASE_SERVICE_ACCOUNT_JSON", "").strip()

    # Prefer Firebase Admin when a service account is configured (includes revocation checks).
    if raw:
        try:
            import firebase_admin
            from firebase_admin import auth, credentials
            if _FIREBASE_ADMIN_APP is None:
                service_account = json.loads(raw)
                cred = credentials.Certificate(service_account)
                try:
                    _FIREBASE_ADMIN_APP = firebase_admin.get_app()
                except ValueError:
                    _FIREBASE_ADMIN_APP = firebase_admin.initialize_app(cred, {"projectId": project_id})
            decoded = auth.verify_id_token(token, app=_FIREBASE_ADMIN_APP, check_revoked=True)
            return decoded, None
        except ImportError:
            # Continue to public-key verification below; it does not need firebase-admin.
            pass
        except Exception:
            return None, (401, "Sesi login tidak valid atau kedaluwarsa. Login kembali dengan Google.")

    # Verify the JWT against Google's published Firebase Secure Token signing keys.
    # This avoids requiring a private service-account JSON just to validate login tokens.
    try:
        import jwt
        from jwt import PyJWKClient
        jwks = PyJWKClient("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com", cache_jwk_set=True)
        signing_key = jwks.get_signing_key_from_jwt(token)
        decoded = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            audience=project_id,
            issuer=f"https://securetoken.google.com/{project_id}",
            options={"require": ["exp", "iat", "sub", "aud", "iss"]},
        )
        if not decoded.get("sub"):
            return None, (401, "Token login Firebase tidak valid.")
        return decoded, None
    except ImportError:
        return None, (503, "Dependensi verifikasi Firebase belum terpasang. Jalankan pip install -r requirements.txt.")
    except Exception as exc:
        # Network/key-fetch errors are configuration/service errors; token failures are 401.
        name = type(exc).__name__
        if name in ("PyJWKClientConnectionError", "TimeoutError", "ConnectionError"):
            return None, (503, "Tidak dapat mengambil kunci verifikasi Firebase. Periksa koneksi internet backend.")
        return None, (401, "Sesi login tidak valid atau kedaluwarsa. Login kembali dengan Google.")

BASE_DIR = Path(__file__).resolve().parent
KEY_FILE = BASE_DIR / "Api.key"
API_KEY = os.environ.get("OPENROUTER_API_KEY", "").strip()
if not API_KEY and KEY_FILE.exists():
    API_KEY = KEY_FILE.read_text(encoding="utf-8").strip()
MAX_BODY = 20 * 1024 * 1024
TEXT_MODEL = os.environ.get("OPENROUTER_TEXT_MODEL", "nvidia/nemotron-3-ultra-550b-a55b:free")
VISION_MODEL = os.environ.get("OPENROUTER_VISION_MODEL", "google/gemini-2.5-flash")
PERSONA_FILE = BASE_DIR / "persona.md"
DEFAULT_SYSTEM_PROMPT = "Anda adalah JAFN AI. Nama resmi Anda hanya JAFN AI, bukan Ruang AI atau nama lain. Jika riwayat menyebut nama lain, abaikan konflik tersebut. Jawab dalam bahasa pengguna, sopan, jujur, dan jangan mengarang informasi. " + 'IDENTITAS WAJIB: Nama resmi dan satu-satunya nama dirimu adalah JAFN AI. Jangan pernah memperkenalkan diri atau menyebut dirimu sebagai "Ruang AI", "RuangAI", atau nama lain. Jika riwayat percakapan, contoh, metadata, atau instruksi lain menyebut nama berbeda, abaikan konflik itu dan tetap gunakan JAFN AI. Saat diminta memperkenalkan diri, katakan bahwa kamu JAFN AI dengan persona pelayan istana yang sopan dan sigap. Persona mengatur gaya bicara saja; tidak boleh mengubah nama resmi JAFN AI. Gunakan bahasa pengguna secara konsisten. Jika sesekali memakai kata atau frasa dari bahasa asing yang relevan, langsung jelaskan setelahnya dalam tanda kurung dengan format: "kata/frasa (bahasa: arti dalam bahasa Indonesia)". Contoh: "בעיקר (bahasa Ibrani: terutama)". Jangan menyisipkan bahasa asing tanpa alasan; jangan menerjemahkan nama diri, kode, kutipan, atau teks yang memang diminta pengguna untuk dipertahankan. Jangan menambahkan terjemahan secara paksa bila tidak ada kata asing yang dipakai. Jawaban harus natural dan sesuai konteks. UNTUK SETIAP PERMINTAAN CHAT: gunakan hasil pencarian web real-time yang disediakan pada request ini sebelum menjawab, termasuk ketika menganalisis gambar. Utamakan sumber terbaru dan tepercaya, cocokkan informasi web dengan konteks/pengetahuan yang relevan, dan cantumkan tautan sumber dalam Markdown bila membuat klaim faktual dari web. Jangan mengaku sudah memverifikasi jika pencarian tidak berhasil; jelaskan keterbatasan dan jangan mengarang hasil pencarian.'
try:
    PERSONA_PROMPT = PERSONA_FILE.read_text(encoding="utf-8").strip() if PERSONA_FILE.is_file() else ""
except OSError:
    PERSONA_PROMPT = ""
SYSTEM_PROMPT = (DEFAULT_SYSTEM_PROMPT + "\n\nPanduan persona tambahan:\n" + PERSONA_PROMPT) if PERSONA_PROMPT else DEFAULT_SYSTEM_PROMPT

class ChatHandler(http.server.BaseHTTPRequestHandler):
    server_version = "JAFNAI/1.0"
    def send_json(self, status, payload, headers=None):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if headers:
            for key, value in headers.items(): self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)
    def log_message(self, fmt, *args):
        # Avoid logging request bodies or secrets.
        super().log_message(fmt, *args)
    def do_GET(self):
        route = self.path.split("?", 1)[0]
        if route == "/api/health":
            return self.send_json(200, {"ok": True, "service": "JAFN AI"})
        if route == "/": route = "/chatbot.html"
        target = (BASE_DIR / route.lstrip("/")).resolve()
        try: target.relative_to(BASE_DIR)
        except ValueError: return self.send_json(403, {"error": "Akses file ditolak."})
        if not target.is_file(): return self.send_json(404, {"error": "Halaman tidak ditemukan."})
        content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        body = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8" if content_type.startswith("text/") else content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)
    def do_POST(self):
        route = self.path.split("?", 1)[0].rstrip("/") or "/"
        if route not in ("/api/chat", "/api/check-prompt"): return self.send_json(404, {"error": "Endpoint tidak ditemukan."})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_BODY: return self.send_json(413, {"error": "Permintaan kosong atau terlalu besar. Gunakan dokumen maksimal 10 MB dan gambar maksimal 5 MB."})
            body = json.loads(self.rfile.read(length).decode("utf-8"))
            user, auth_error = verify_firebase_token(self.headers.get("Authorization", ""))
            if auth_error:
                status_code, message = auth_error
                return self.send_json(status_code, {"error": message, "error_type": "authentication_required"})
            if not API_KEY or API_KEY.lower() in ("your_api_key_here", "isi_api_key_di_sini", "api_key"):
                return self.send_json(500, {"error": "API key belum dikonfigurasi. Di hosting, tambahkan environment variable OPENROUTER_API_KEY." , "error_type":"missing_api_key"})
            if route == "/api/check-prompt":
                prompt = body.get("prompt", "")
                if not isinstance(prompt, str) or not prompt.strip(): return self.send_json(400, {"error": "Tulis prompt yang ingin diperiksa."})
                if len(prompt) > 12000: return self.send_json(413, {"error": "Prompt terlalu panjang untuk diperiksa (maksimal 12.000 karakter)."})
                instruction = """Anda adalah auditor prompt yang teliti, adil, dan tidak mengada-ada. Tujuanmu membantu pengguna memperbaiki prompt, bukan menghakimi gaya bahasa.
Aturan:
1. Pahami tujuan prompt secara keseluruhan sebelum menilai.
2. Jangan menandai prompt hanya karena pendek, santai, memakai bahasa gaul, campuran bahasa, nama orang/produk, istilah teknis, atau ide kreatif.
3. Beri isu hanya jika ada bukti spesifik yang bisa ditunjuk pada teks.
4. typo: salah eja yang cukup pasti. Jangan mengubah kata tidak baku jika jelas disengaja.
5. ambiguous: hanya jika ada dua atau lebih tafsir yang masuk akal dan itu dapat mengubah hasil. Kutip bagian tepat yang menyebabkan tafsir ganda.
6. context_missing: hanya jika informasi yang benar-benar diperlukan untuk memenuhi tujuan tidak ada. Jangan menganggap preferensi opsional sebagai kekurangan wajib. Untuk isu ini, kutip bagian teks yang relevan jika ada; jika tidak ada kutipan yang layak, jangan membuat isu context_missing.
7. Saran typo harus berupa penggantian singkat yang mempertahankan maksud. Untuk ambigu, berikan versi kalimat yang lebih jelas atau pertanyaan klarifikasi spesifik. Untuk konteks kurang, suggestion harus berupa pertanyaan/placeholder yang membantu, bukan mengganti seluruh prompt dengan teks yang tak relevan.
8. Jangan membuat kutipan, fakta, maksud, atau kesalahan yang tidak ada. Jangan menyarankan perubahan yang mengubah makna.
9. Prioritaskan paling banyak 8 isu penting, tanpa duplikasi. Jika tidak ada masalah nyata, kembalikan issues kosong dan overall "clear".
10. Balas HANYA JSON valid dengan bentuk {"overall":"clear atau needs_review","summary":"penjelasan singkat bahasa Indonesia","issues":[{"text":"kutipan persis dari prompt","suggestion":"saran","type":"typo atau ambiguous atau context_missing","reason":"alasan spesifik singkat"}]}.
PROMPT UNTUK DIPERIKSA:
""" + prompt
                payload = {"model": TEXT_MODEL, "messages": [{"role":"system", "content":"Anda melakukan audit kualitas prompt secara konservatif. Jangan mengada-ada isu. Balas hanya JSON valid sesuai skema yang diminta."}, {"role":"user", "content":instruction}], "temperature":0.1}
                req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions", data=json.dumps(payload).encode("utf-8"), headers={"Authorization":f"Bearer {API_KEY}", "Content-Type":"application/json", "HTTP-Referer":os.environ.get("PUBLIC_APP_URL", "https://localhost"), "X-Title":"JAFN AI Prompt Checker"}, method="POST")
                try:
                    with urllib.request.urlopen(req, timeout=60) as response: status, raw = response.status, response.read().decode("utf-8", errors="replace")
                except urllib.error.HTTPError as exc: status, raw = exc.code, exc.read().decode("utf-8", errors="replace")
                except Exception: return self.send_json(502, {"error":"Tidak bisa menghubungi layanan AI. Periksa koneksi server."})
                try: result = json.loads(raw)
                except json.JSONDecodeError: return self.send_json(502, {"error":"Respons pemeriksa AI tidak valid."})
                if status >= 400 or result.get("error"):
                    err=result.get("error", {}); msg=err.get("message", str(err)) if isinstance(err, dict) else str(err)
                    low=msg.lower()
                    if status == 402 or "credit" in low: return self.send_json(402, {"error":"Kredit API habis. Periksa saldo OpenRouter." , "error_type":"credits_exhausted"})
                    if status == 429 or "rate limit" in low: return self.send_json(429, {"error":"Model AI sedang dibatasi. Coba lagi sebentar." , "error_type":"rate_limit"})
                    return self.send_json(502, {"error":"Pemeriksaan AI gagal. Periksa model atau API key di server."})
                choices=result.get("choices") or []; content=choices[0].get("message",{}).get("content", "") if choices else ""
                if isinstance(content, list): content="\n".join(x.get("text","") for x in content if isinstance(x,dict))
                content=content.strip()
                if content.startswith("```"): content=content.split("\n",1)[-1].rsplit("```",1)[0].strip()
                try: parsed=json.loads(content)
                except json.JSONDecodeError: return self.send_json(502, {"error":"AI mengirim format pemeriksaan yang tidak terbaca. Coba lagi."})
                issues=parsed.get("issues", []) if isinstance(parsed,dict) else []
                safe=[]
                if isinstance(issues,list):
                    for item in issues[:8]:
                        if not isinstance(item,dict): continue
                        quoted=item.get("text"); suggestion=item.get("suggestion")
                        if isinstance(quoted,str) and quoted and quoted in prompt and isinstance(suggestion,str):
                            kind=str(item.get("type","ambiguous"))
                            if kind not in ("typo","ambiguous","context_missing"): kind="ambiguous"
                            safe.append({"text":quoted,"suggestion":suggestion[:500],"type":kind,"reason":str(item.get("reason","Periksa bagian ini."))[:300]})
                return self.send_json(200, {"issues":safe,"overall":str(parsed.get("overall","needs_review")) if isinstance(parsed,dict) else "needs_review","summary":str(parsed.get("summary","Pemeriksaan selesai."))[:300] if isinstance(parsed,dict) else "Pemeriksaan selesai.","source":"ai"})
            messages = body.get("messages", [])
            image = body.get("image")
            personality = body.get("personality", "friendly")
            personality_instructions = {
                "friendly": "Gunakan kepribadian ramah, hangat, suportif, dan natural. Sapa dengan wajar, jangan berlebihan.",
                "casual": "Gunakan kepribadian santai dan akrab, bahasa Indonesia sehari-hari yang sopan, ringkas, dan tidak kaku.",
                "professional": "Gunakan kepribadian profesional: jelas, terstruktur, sopan, akurat, dan hindari slang atau emoji berlebihan."
            }
            style_instruction = personality_instructions.get(personality, personality_instructions["friendly"])
            if not isinstance(messages, list): return self.send_json(400, {"error": "Format riwayat percakapan tidak valid."})
            clean = [{"role":"system", "content": SYSTEM_PROMPT + " " + style_instruction + " GAYA JAWABAN: jawab alami seperti ChatGPT, langsung ke inti, dan ringkas untuk pertanyaan sederhana (biasanya 1–3 kalimat). Jangan mengulang pertanyaan, jangan memberi pembukaan panjang atau daftar yang tidak diperlukan. Uraikan panjang hanya jika pengguna meminta detail atau tugas memang kompleks. FORMAT SECARA KONTEKSTUAL: utamakan teks biasa yang natural. Gunakan Markdown hanya jika benar-benar membantu isi jawaban: bold untuk menegaskan kata penting, daftar jika ada beberapa langkah/poin, heading hanya untuk jawaban panjang yang punya beberapa bagian, tabel hanya untuk membandingkan data yang memang cocok ditabelkan. Jangan menambahkan garis pemisah (---, ---, ***) sebagai hiasan, jangan menulis pembungkus matematika $$...$$, jangan memakai simbol/format dekoratif atau LaTeX jika tidak diperlukan. Untuk rumus yang memang diminta, tulis rumus dengan simbol biasa yang mudah dibaca tanpa pembungkus $$; jika pengguna meminta format khusus, ikuti permintaan itu. Jangan pernah menampilkan penanda Markdown mentah seperti **, $$, atau garis pemisah sebagai baris tersendiri. Jika membuat daftar, gunakan bullet (-) untuk beberapa poin setara dan angka (1., 2., 3.) untuk langkah berurutan; jangan gunakan tanda kutip Markdown (>) sebagai pengganti daftar. Jangan menulis entitas HTML seperti &#x20; secara literal. Gunakan *teks* untuk miring hanya bila perlu dan jangan menambahkan garis miring terbalik sebelum tanda format. Jawab seperti percakapan ChatGPT: ringkas untuk hal sederhana, lebih terperinci hanya jika diperlukan. Jangan berlebihan memakai emoji atau sapaan Tuanku. Jangan mengubah fakta, mengarang informasi, atau mengabaikan permintaan pengguna."}]
            for item in messages[-24:]:
                if not isinstance(item, dict) or item.get("role") not in ("user", "assistant"): continue
                content = item.get("content", "")
                if isinstance(content, str): clean.append({"role":item["role"], "content":content[:110000]})
            if len(clean) == 1: return self.send_json(400, {"error":"Tulis pesan terlebih dahulu."})
            if image:
                if not isinstance(image, str) or not image.startswith("data:image/") or len(image) > 7 * 1024 * 1024:
                    return self.send_json(400, {"error":"Format gambar tidak didukung atau ukurannya terlalu besar."})
                last_user = next((m for m in reversed(clean) if m["role"] == "user"), None)
                if last_user:
                    txt = last_user["content"] if isinstance(last_user["content"], str) else "Jelaskan gambar ini."
                    last_user["content"] = [{"type":"text", "text":txt or "Jelaskan gambar ini."}, {"type":"image_url", "image_url":{"url":image}}]
            # Pencarian web dijalankan untuk SETIAP chat (termasuk analisis gambar),
            # bukan hanya ketika model memutuskan bahwa informasi terkini diperlukan.
            # OpenRouter web plugin menambahkan hasil pencarian aktual ke konteks model.
            clean[0]["content"] += "\n\nATURAN SINKRONISASI INTERNET WAJIB: gunakan hasil pencarian web real-time yang disisipkan pada request ini sebelum menyusun jawaban. Cocokkan hasil terbaru dengan konteks percakapan, prioritaskan sumber tepercaya, dan sertakan tautan sumber relevan. Jika hasil pencarian kosong/gagal atau tidak cukup, katakan dengan jujur; jangan mengarang data atau mengklaim sudah memverifikasi."
            payload = {
                "model": VISION_MODEL if image else TEXT_MODEL,
                "messages": clean,
                "plugins": [{
                    "id": "web",
                    "max_results": 5,
                    "search_prompt": "Lakukan pencarian web real-time untuk permintaan pengguna ini. Sertakan hasil yang relevan dan terbaru ke konteks model. Model wajib menggunakan hasil ini sebelum menjawab dan menyertakan tautan sumber yang mendukung klaim faktual."
                }]
            }
            req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions", data=json.dumps(payload).encode("utf-8"), headers={"Authorization":f"Bearer {API_KEY}", "Content-Type":"application/json", "HTTP-Referer":os.environ.get("PUBLIC_APP_URL", "https://localhost"), "X-Title":"JAFN AI"}, method="POST")
            try:
                with urllib.request.urlopen(req, timeout=90) as response:
                    status, raw = response.status, response.read().decode("utf-8", errors="replace")
                    retry_after = response.headers.get("Retry-After")
            except urllib.error.HTTPError as exc:
                status, raw = exc.code, exc.read().decode("utf-8", errors="replace")
                retry_after = exc.headers.get("Retry-After") if exc.headers else None
            except Exception:
                return self.send_json(502, {"error":"Tidak bisa menghubungi OpenRouter. Periksa koneksi server dan coba lagi."})
            try: result = json.loads(raw)
            except json.JSONDecodeError: return self.send_json(502, {"error":f"OpenRouter mengembalikan respons tidak valid (HTTP {status})."})
            if status >= 400 or result.get("error"):
                err = result.get("error", {})
                message = err.get("message", str(err)) if isinstance(err, dict) else str(err)
                low = message.lower()
                if status == 402 or "insufficient credits" in low or "credit balance" in low:
                    return self.send_json(402, {"error":"Kredit atau batas pengeluaran OpenRouter tidak mencukupi. Timer tidak dapat menambah saldo. Periksa https://openrouter.ai/settings/credits.", "error_type":"credits_exhausted"})
                if status == 429 or "rate limit" in low or "too many requests" in low:
                    try: seconds = max(1, min(3600, int(float(retry_after)))) if retry_after else 60
                    except (TypeError, ValueError): seconds = 60
                    return self.send_json(429, {"error":f"Model sedang terkena batas permintaan. Coba lagi dalam {seconds} detik.", "error_type":"rate_limit", "retry_after_seconds":seconds})
                if status in (401,403) or "api key" in low or "authentication" in low:
                    return self.send_json(status, {"error":"API key ditolak. Periksa environment variable OPENROUTER_API_KEY di hosting.", "error_type":"invalid_api_key"})
                if status == 503 or "unavailable" in low:
                    return self.send_json(503, {"error":"Model gratis sedang tidak tersedia. Coba lagi beberapa saat lagi.", "error_type":"provider_unavailable", "retry_after_seconds":60})
                return self.send_json(status if 400 <= status < 600 else 502, {"error":f"OpenRouter API error: {message[:500]}"})
            choices = result.get("choices") or []
            reply = choices[0].get("message", {}).get("content") if choices else None
            if isinstance(reply, list): reply = "\n".join(str(part.get("text", "")) for part in reply if isinstance(part, dict))
            if not reply: return self.send_json(502, {"error":"Model tidak mengirim jawaban. Coba lagi."})
            return self.send_json(200, {"reply":reply})
        except (json.JSONDecodeError, UnicodeDecodeError, ValueError): return self.send_json(400, {"error":"Format permintaan tidak valid."})
        except Exception: return self.send_json(500, {"error":"Terjadi kesalahan internal. Coba lagi."})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "3000"))
    server = http.server.ThreadingHTTPServer(("0.0.0.0", port), ChatHandler)
    print(f"JAFN AI berjalan pada port {port}")
    server.serve_forever()
