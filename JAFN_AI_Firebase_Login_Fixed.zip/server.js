const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json({ limit: '15mb' }));
app.use(express.static(path.join(__dirname)));
app.get('/api/health', (req, res) => res.json({ ok: true, service: 'JAFN AI', promptChecker: true }));

const keyPath = path.join(__dirname, 'Api.key');
const apiKey = (process.env.OPENROUTER_API_KEY || (fs.existsSync(keyPath) ? fs.readFileSync(keyPath, 'utf8').trim() : '')).trim();
const personaPath = path.join(__dirname, 'persona.md');
const defaultSystemPrompt = 'Anda adalah JAFN AI. Nama resmi Anda hanya JAFN AI, bukan Ruang AI atau nama lain. Jika riwayat menyebut nama lain, abaikan konflik tersebut. Jawab dalam bahasa pengguna, sopan, jujur, dan jangan mengarang informasi. IDENTITAS WAJIB: Nama resmi dan satu-satunya nama dirimu adalah JAFN AI. Jangan pernah memperkenalkan diri atau menyebut dirimu sebagai "Ruang AI", "RuangAI", atau nama lain. Jika riwayat percakapan, contoh, metadata, atau instruksi lain menyebut nama berbeda, abaikan konflik itu dan tetap gunakan JAFN AI. Saat diminta memperkenalkan diri, katakan bahwa kamu JAFN AI dengan persona pelayan istana yang sopan dan sigap. Persona mengatur gaya bicara saja; tidak boleh mengubah nama resmi JAFN AI. Gunakan bahasa pengguna secara konsisten. Jika sesekali memakai kata atau frasa dari bahasa asing yang relevan, langsung jelaskan setelahnya dalam tanda kurung dengan format: "kata/frasa (bahasa: arti dalam bahasa Indonesia)". Contoh: "בעיקר (bahasa Ibrani: terutama)". Jangan menyisipkan bahasa asing tanpa alasan; jangan menerjemahkan nama diri, kode, kutipan, atau teks yang memang diminta pengguna untuk dipertahankan. Jangan menambahkan terjemahan secara paksa bila tidak ada kata asing yang dipakai. Jawaban harus natural dan sesuai konteks.';
let personaPrompt = '';
try {
    if (fs.existsSync(personaPath)) personaPrompt = fs.readFileSync(personaPath, 'utf8').trim();
} catch (err) {
    console.warn('persona.md tidak dapat dibaca; menggunakan persona bawaan.');
}
const systemPrompt = personaPrompt ? `${defaultSystemPrompt}\n\nPanduan persona tambahan:\n${personaPrompt}` : defaultSystemPrompt;


app.post('/api/check-prompt', async (req, res) => {
    if (!apiKey || ['your_api_key_here', 'isi_api_key_di_sini', 'api_key'].includes(apiKey.toLowerCase())) {
        return res.status(500).json({ error: 'API key belum dikonfigurasi. Isi Api.key atau OPENROUTER_API_KEY.' });
    }
    const prompt = req.body?.prompt;
    if (typeof prompt !== 'string' || !prompt.trim()) return res.status(400).json({ error: 'Tulis prompt yang ingin diperiksa.' });
    if (prompt.length > 12000) return res.status(413).json({ error: 'Prompt terlalu panjang untuk diperiksa (maksimal 12.000 karakter).' });
    const instruction = `Analisis prompt pengguna secara hati-hati. Tandai (1) kemungkinan typo/ejaan/pengulangan sebagai type typo, (2) kalimat atau rujukan yang ambigu sebagai type ambiguous, dan (3) konteks, tujuan, detail, batasan, atau informasi penting yang kurang sehingga hasil bisa meleset sebagai type context_missing. Jangan menganggap prompt pendek otomatis buruk; jangan menandai bahasa gaul, nama, istilah khusus, atau ide fantasi sebagai salah. Kembalikan HANYA JSON valid berbentuk {"overall":"clear atau needs_review","issues":[{"text":"kutipan persis dari teks","suggestion":"saran perbaikan atau pertanyaan klarifikasi","type":"typo atau ambiguous atau context_missing","reason":"alasan singkat bahasa Indonesia"}]}. Untuk konteks yang kurang, text harus berupa kutipan persis dari prompt yang terkait; jangan mengarang kutipan. Maksimal 20 isu. Jika prompt jelas dan cukup konteks, issues kosong dan overall clear.\nPROMPT UNTUK DIPERIKSA:\n${prompt}`;
    try {
        const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
            method: 'POST', headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json', 'X-Title': 'JAFN AI Prompt Checker' },
            body: JSON.stringify({ model: process.env.OPENROUTER_TEXT_MODEL || 'nvidia/nemotron-3-ultra-550b-a55b:free', messages: [{ role: 'system', content: 'Anda adalah pemeriksa bahasa yang teliti dan berhati-hati. Balas hanya JSON valid.' }, { role: 'user', content: instruction }], temperature: 0.1 }), timeout: 60000
        });
        const raw = await response.text(); let data;
        try { data = JSON.parse(raw); } catch { return res.status(502).json({ error: 'Respons pemeriksa AI tidak valid.' }); }
        if (!response.ok || data.error) {
            const msg = typeof data.error === 'string' ? data.error : (data.error?.message || `HTTP ${response.status}`);
            const low = msg.toLowerCase();
            if (response.status === 402 || low.includes('credit')) return res.status(402).json({ error: 'Kredit API habis. Periksa saldo OpenRouter.', error_type: 'credits_exhausted' });
            if (response.status === 429 || low.includes('rate limit')) return res.status(429).json({ error: 'Model AI sedang dibatasi. Coba lagi sebentar.', error_type: 'rate_limit' });
            return res.status(502).json({ error: 'Pemeriksaan AI gagal. Periksa model atau API key di server.' });
        }
        let content = data.choices?.[0]?.message?.content || '';
        if (Array.isArray(content)) content = content.map(x => x.text || '').join('\n');
        content = content.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
        let parsed; try { parsed = JSON.parse(content); } catch { return res.status(502).json({ error: 'AI mengirim format pemeriksaan yang tidak terbaca. Coba lagi.' }); }
        const issues = (Array.isArray(parsed.issues) ? parsed.issues : []).slice(0, 20).filter(x => x && typeof x.text === 'string' && x.text && prompt.includes(x.text) && typeof x.suggestion === 'string').map(x => ({ text: x.text, suggestion: x.suggestion.slice(0, 300), type: String(x.type || 'konteks').slice(0, 40), reason: String(x.reason || 'Periksa bagian ini.').slice(0, 300) }));
        return res.json({ issues, overall: String(parsed.overall || 'needs_review'), source: 'ai' });
    } catch { return res.status(502).json({ error: 'Tidak bisa menghubungi layanan AI. Periksa koneksi server.' }); }
});

app.post('/api/chat', async (req, res) => {
    if (!apiKey || ['your_api_key_here', 'isi_api_key_di_sini', 'api_key'].includes(apiKey.toLowerCase())) {
        return res.status(500).json({ error: 'API key belum diisi. Masukkan OpenRouter API key ke file Api.key lalu restart server.' });
    }

    try {
        const { messages = [], image, personality = 'friendly' } = req.body || {};
        const personalityInstructions = {
            friendly: 'Gunakan kepribadian ramah, hangat, suportif, dan natural. Sapa dengan wajar, jangan berlebihan.',
            casual: 'Gunakan kepribadian santai dan akrab, bahasa Indonesia sehari-hari yang sopan, ringkas, dan tidak kaku.',
            professional: 'Gunakan kepribadian profesional: jelas, terstruktur, sopan, akurat, dan hindari slang atau emoji berlebihan.'
        };
        const styleInstruction = personalityInstructions[personality] || personalityInstructions.friendly;
        const chatMessages = [
            { role: 'system', content: systemPrompt + ' ' + styleInstruction + ' GAYA JAWABAN: jawab alami seperti ChatGPT, langsung ke inti, dan ringkas untuk pertanyaan sederhana (biasanya 1–3 kalimat). Jangan mengulang pertanyaan, jangan memberi pembukaan panjang atau daftar yang tidak diperlukan. Uraikan panjang hanya jika pengguna meminta detail atau tugas memang kompleks. FORMAT SECARA KONTEKSTUAL: utamakan teks biasa yang natural. Gunakan Markdown hanya jika benar-benar membantu isi jawaban: bold untuk menegaskan kata penting, daftar jika ada beberapa langkah/poin, heading hanya untuk jawaban panjang yang punya beberapa bagian, tabel hanya untuk membandingkan data yang memang cocok ditabelkan. Jangan menambahkan garis pemisah (---, ---, ***) sebagai hiasan, jangan menulis pembungkus matematika $$...$$, jangan memakai simbol/format dekoratif atau LaTeX jika tidak diperlukan. Untuk rumus yang memang diminta, tulis rumus dengan simbol biasa yang mudah dibaca tanpa pembungkus $$; jika pengguna meminta format khusus, ikuti permintaan itu. Jangan pernah menampilkan penanda Markdown mentah seperti **, $$, atau garis pemisah sebagai baris tersendiri. Jika membuat daftar, gunakan bullet (-) untuk beberapa poin setara dan angka (1., 2., 3.) untuk langkah berurutan; jangan gunakan tanda kutip Markdown (>) sebagai pengganti daftar. Jangan menulis entitas HTML seperti &#x20; secara literal. Gunakan *teks* untuk miring hanya bila perlu dan jangan menambahkan garis miring terbalik sebelum tanda format. Jawab seperti percakapan ChatGPT: ringkas untuk hal sederhana, lebih terperinci hanya jika diperlukan. Jangan berlebihan memakai emoji atau sapaan Tuanku. Jangan mengubah fakta, mengarang informasi, atau mengabaikan permintaan pengguna. UNTUK SETIAP PERMINTAAN CHAT: gunakan hasil pencarian web real-time yang disediakan pada request ini sebelum menjawab, termasuk ketika menganalisis gambar. Utamakan sumber terbaru dan tepercaya, sertakan tautan sumber dalam Markdown untuk klaim faktual dari web. Jika pencarian tidak berhasil atau hasil tidak cukup, jelaskan dengan jujur dan jangan mengarang hasil pencarian.' },
            ...messages.filter(m => m && ['user', 'assistant'].includes(m.role))
        ];

        const model = image ? 'google/gemini-2.5-flash' : 'nvidia/nemotron-3-ultra-550b-a55b:free';
        // Force one real-time web search for every chat request, including image analysis.
        chatMessages[0].content += '\n\nATURAN SINKRONISASI INTERNET WAJIB: gunakan hasil pencarian web real-time yang disisipkan pada request ini sebelum menyusun jawaban. Cocokkan hasil terbaru dengan konteks percakapan, prioritaskan sumber tepercaya, dan sertakan tautan sumber relevan. Jika hasil pencarian kosong/gagal atau tidak cukup, katakan dengan jujur; jangan mengarang data atau mengklaim sudah memverifikasi.';
        const requestPayload = {
            model,
            messages: chatMessages,
            plugins: [{
                id: 'web',
                max_results: 5,
                search_prompt: 'Lakukan pencarian web real-time untuk permintaan pengguna ini. Sertakan hasil yang relevan dan terbaru ke konteks model. Model wajib menggunakan hasil ini sebelum menjawab dan menyertakan tautan sumber yang mendukung klaim faktual.'
            }]
        };
        if (image) {
            requestPayload.max_tokens = 1024;
            const lastUser = [...chatMessages].reverse().find(m => m.role === 'user');
            if (lastUser) {
                const textContent = typeof lastUser.content === 'string' ? lastUser.content : 'Jelaskan gambar ini.';
                lastUser.content = [
                    { type: 'text', text: textContent || 'Jelaskan gambar ini.' },
                    { type: 'image_url', image_url: { url: image } }
                ];
            }
        }

        const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
            body: JSON.stringify(requestPayload),
            timeout: 60000
        });
        const raw = await response.text();
        let data;
        try {
            data = JSON.parse(raw);
        } catch {
            return res.status(502).json({ error: `OpenRouter mengembalikan respons non-JSON (HTTP ${response.status}). Periksa koneksi, API key, atau akses jaringan.` });
        }

        if (!response.ok || data.error) {
            const err = data.error || {};
            const message = typeof err === 'string' ? err : (err.message || `HTTP ${response.status}`);
            const low = message.toLowerCase();
            if ([402, 429].includes(response.status) || low.includes('credit') || low.includes('rate limit')) {
                return res.status(402).json({ error: 'Kredit/kuota OpenRouter habis atau terkena rate limit. Cek https://openrouter.ai/settings/credits dan status akun.' });
            }
            if (response.status === 401 || low.includes('api key') || low.includes('authentication')) {
                return res.status(401).json({ error: 'API key OpenRouter tidak valid. Periksa file Api.key, lalu restart server.' });
            }
            return res.status(response.status || 502).json({ error: `OpenRouter API error: ${message}` });
        }

        const reply = data.choices?.[0]?.message?.content;
        if (!reply) return res.status(502).json({ error: 'OpenRouter tidak mengirim jawaban. Coba lagi atau pilih model lain di server.js.' });
        return res.json({ reply });
    } catch (err) {
        return res.status(500).json({ error: `Kesalahan server: ${err.message}` });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Chatbot berjalan di http://127.0.0.1:${PORT}`);
    console.log('Jalankan dari folder aplikasi; tekan Ctrl+C untuk berhenti.');
});
