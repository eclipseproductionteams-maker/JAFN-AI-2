/* Firebase Authentication + Firestore cloud sync for JAFN AI.
   Firebase web config is public by design; protect data with firestore.rules. */
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { getFirestore, doc, getDoc, setDoc, collection, getDocs, writeBatch, deleteDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';

const firebaseConfig = {
  apiKey: 'AIzaSyDPxANYoZFLMd_gr4oP9PEsQsaMLaHGr4o',
  authDomain: 'jafn-ai.firebaseapp.com',
  projectId: 'jafn-ai',
  storageBucket: 'jafn-ai.firebasestorage.app',
  messagingSenderId: '868530308242',
  appId: '1:868530308242:web:889da8a1f744c7ba3b524b',
  measurementId: 'G-23N9M1PYZ8'
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: 'select_account' });
const KEYS = [
  'ruangai_history','ruangai_image_history','ruangai_theme','ruangai_style',
  'ruangai_personalization','jafn_companion_settings_v1','jafn_privacy_save_history',
  'jafn_privacy_save_preferences','jafn_privacy_memory','jafn_onboarding_done_v1',
  'ruangai_arcade_v1','jafn_usage_total_v1','jafn_usage_daily_v1','jafn_response_feedback_v1'
];
const CHAT_KEY = 'ruangai_chats';
let currentUser = null;
let cloudReady = false;
let syncTimer = null;
let syncBusy = false;
let syncAgain = false;

function addAuthControl() {
  if (document.getElementById('jafnAuthControl')) return;
  const header = document.querySelector('header');
  if (!header) return;
  const wrap = document.createElement('div');
  wrap.id = 'jafnAuthControl';
  wrap.style.cssText = 'display:flex;align-items:center;gap:8px;max-width:220px;margin-left:4px;';
  const btn = document.createElement('button');
  btn.type = 'button'; btn.id = 'jafnAuthButton';
  btn.style.cssText = 'border:1px solid var(--line,#64748b);border-radius:12px;padding:9px 12px;background:var(--panel2,#202638);color:var(--text,#fff);font-weight:650;cursor:pointer;white-space:nowrap;max-width:190px;overflow:hidden;text-overflow:ellipsis;';
  btn.textContent = '🔐 Login Google';
  btn.addEventListener('click', async () => {
    btn.disabled = true;
    try {
      if (auth.currentUser) {
        if (!confirm('Logout dari JAFN AI? Data yang sudah tersinkron tetap tersimpan di akunmu.')) return;
        await flushCloudSync();
        await signOut(auth);
      } else {
        await signInWithPopup(auth, provider);
      }
    } catch (e) {
      console.error('Firebase auth error', e);
      const code = e?.code || 'unknown';
      if (code === 'auth/unauthorized-domain') {
        const host = window.location.hostname || '(hostname tidak tersedia)';
        const origin = window.location.origin || window.location.href;
        alert(
          'Domain aplikasi belum diizinkan oleh Firebase Authentication.\n\n' +
          'Domain yang sedang dipakai: ' + host + '\n' +
          'Alamat aplikasi: ' + origin + '\n\n' +
          'Perbaikan: buka Firebase Console > Authentication > Settings > Authorized domains > Add domain, lalu tambahkan hostname di atas (tanpa https://, path, atau port). ' +
          'Jika berjalan lokal, coba buka http://localhost:3000 dan tambahkan localhost bila belum ada. ' +
          'Pastikan juga Authentication > Sign-in method > Google sudah Enabled.\n\n' +
          'Perubahan kode saja tidak dapat menambahkan domain ke daftar Firebase.'
        );
      } else {
        alert('Login/logout gagal. Detail: ' + code + (e?.message ? '\n' + e.message : '') +
          '\nPeriksa koneksi internet dan status Google provider di Firebase Authentication.');
      }
    } finally { btn.disabled = false; }
  });
  const status = document.createElement('span');
  status.id = 'jafnAuthStatus'; status.style.cssText = 'font-size:11px;color:var(--muted,#94a3b8);display:none;';
  wrap.append(btn, status);
  const arcade = document.getElementById('arcadeBtn');
  if (arcade?.parentElement === header) header.insertBefore(wrap, arcade); else header.append(wrap);
  const style = document.createElement('style');
  style.textContent = '@media(max-width:700px){#jafnAuthControl{max-width:145px}#jafnAuthButton{font-size:11px;padding:7px 8px;max-width:145px}}';
  document.head.append(style);
}
function updateAuthUI(user) {
  const btn = document.getElementById('jafnAuthButton');
  const status = document.getElementById('jafnAuthStatus');
  if (!btn) return;
  if (user) {
    btn.textContent = '👤 ' + (user.displayName || user.email || 'Akun Google');
    btn.title = `${user.displayName || ''} ${user.email || ''}\nKlik untuk logout`;
    if (status) { status.style.display = 'block'; status.textContent = cloudReady ? '☁️ Tersinkron' : '☁️ Menyiapkan data…'; }
  } else {
    btn.textContent = '🔐 Login Google'; btn.title = 'Login untuk menyimpan riwayat dan pengaturan ke cloud';
    if (status) { status.style.display = 'block'; status.textContent = 'Riwayat lokal saja'; }
  }
}
function safeChat(chat) {
  const copy = { id: String(chat.id || '').slice(0,150), mode: chat.mode === 'image' ? 'image' : 'text', title: String(chat.title || 'Percakapan').slice(0,100), updated: Number(chat.updated) || Date.now(), messages: [] };
  for (const m of (Array.isArray(chat.messages) ? chat.messages : []).slice(-50)) {
    if (!m || !['user','assistant'].includes(m.role)) continue;
    const content = typeof m.content === 'string' ? m.content.slice(-12000) : '';
    copy.messages.push({ role: m.role, content });
  }
  return copy;
}
async function syncChats(value) {
  if (!currentUser || !cloudReady) return;
  if (localStorage.getItem('jafn_privacy_save_history') === 'false') value = '[]';
  let chats;
  try { chats = JSON.parse(value || '[]'); } catch { return; }
  if (!Array.isArray(chats)) return;
  const ref = collection(db, 'users', currentUser.uid, 'chats');
  const existing = await getDocs(ref);
  const wanted = new Set(chats.slice(0, 100).map(c => String(c.id || '')).filter(id => id && !id.includes('/')));
  let batch = writeBatch(db), count = 0;
  for (const c of chats.slice(0, 100)) {
    const item = safeChat(c); if (!item.id || item.id.includes('/')) continue;
    batch.set(doc(ref, item.id), { ...item, updatedAt: serverTimestamp() }); count++;
    if (count >= 400) { await batch.commit(); batch = writeBatch(db); count = 0; }
  }
  for (const old of existing.docs) if (!wanted.has(old.id)) { batch.delete(old.ref); count++; if (count >= 400) { await batch.commit(); batch = writeBatch(db); count = 0; } }
  if (count) await batch.commit();
}
async function syncSetting(key, value) {
  if (!currentUser || !cloudReady || !KEYS.includes(key)) return;
  if (typeof value !== 'string' || value.length > 45000) return;
  await setDoc(doc(db, 'users', currentUser.uid, 'settings', key), { value, updatedAt: serverTimestamp() });
}
function queueSync(key, value) {
  if (!currentUser || !cloudReady) return;
  clearTimeout(syncTimer);
  syncTimer = setTimeout(async () => {
    try {
      if (key === CHAT_KEY) await syncChats(value);
      else await syncSetting(key, value);
      const status = document.getElementById('jafnAuthStatus'); if (status) status.textContent = '☁️ Tersinkron';
    } catch (e) {
      console.error('Cloud sync failed', e);
      const status = document.getElementById('jafnAuthStatus'); if (status) status.textContent = '⚠️ Sinkronisasi gagal';
    }
  }, 700);
}
const originalSetItem = Storage.prototype.setItem;
Storage.prototype.setItem = function(key, value) {
  originalSetItem.call(this, key, value);
  if (this === window.localStorage && (key === CHAT_KEY || KEYS.includes(key))) queueSync(key, String(value));
};
const originalRemoveItem = Storage.prototype.removeItem;
Storage.prototype.removeItem = function(key) {
  originalRemoveItem.call(this, key);
  if (this === window.localStorage && (key === CHAT_KEY || KEYS.includes(key)) && currentUser && cloudReady) {
    if (key === CHAT_KEY) queueSync(key, '[]');
    else queueSync(key, '');
  }
};
async function flushCloudSync() {
  if (!currentUser || !cloudReady) return;
  clearTimeout(syncTimer);
  const chats = localStorage.getItem(CHAT_KEY);
  if (chats !== null) await syncChats(chats);
  for (const key of KEYS) { const value = localStorage.getItem(key); if (value !== null) await syncSetting(key, value); }
}
async function loadCloudState(user) {
  const settingsRef = collection(db, 'users', user.uid, 'settings');
  const chatsRef = collection(db, 'users', user.uid, 'chats');
  const [settingsSnap, chatsSnap] = await Promise.all([getDocs(settingsRef), getDocs(chatsRef)]);
  const hasCloudData = !settingsSnap.empty || !chatsSnap.empty;
  const userKeys = [...KEYS, CHAT_KEY];
  // Capture local chats before replacing local state. Settings can exist in cloud
  // while the chats subcollection is still empty; that must not erase local chats.
  const localChats = localStorage.getItem(CHAT_KEY);
  const historyDisabled = settingsSnap.docs.some(s => s.id === 'jafn_privacy_save_history' && s.data().value === 'false');

  if (hasCloudData) {
    // Use the original Storage methods to avoid queuing deletion syncs while loading.
    userKeys.forEach(k => { try { originalRemoveItem.call(localStorage, k); } catch {} });
    settingsSnap.forEach(s => {
      const d = s.data();
      if (KEYS.includes(s.id) && typeof d.value === 'string') originalSetItem.call(localStorage, s.id, d.value);
    });

    let chats = chatsSnap.docs.map(d => d.data()).map(safeChat)
      .sort((a,b)=>(b.updated||0)-(a.updated||0));
    if (!historyDisabled && chatsSnap.empty && localChats) {
      // Cloud has settings but no chats yet: preserve/import local conversations.
      try {
        const parsed = JSON.parse(localChats);
        if (Array.isArray(parsed) && parsed.length) {
          chats = parsed.map(safeChat).filter(c => c.id);
          await syncChats(JSON.stringify(chats));
        }
      } catch (e) { console.warn('Local chat import skipped: invalid chat data', e); }
    }
    originalSetItem.call(localStorage, CHAT_KEY, JSON.stringify(historyDisabled ? [] : chats));
  } else {
    // First login: import local history/settings from this browser into the user's cloud account.
    if (localChats) await syncChats(localChats);
    for (const key of KEYS) { const value = localStorage.getItem(key); if (value !== null) await syncSetting(key, value); }
  }
  await setDoc(doc(db, 'users', user.uid), { uid: user.uid, displayName: user.displayName || '', email: user.email || '', photoURL: user.photoURL || '', lastLoginAt: serverTimestamp() }, { merge: true });
}
addAuthControl();
window.jafnGetAuthToken = async () => auth.currentUser ? await auth.currentUser.getIdToken() : null;
window.jafnFirebaseUser = () => auth.currentUser ? ({ uid: auth.currentUser.uid, email: auth.currentUser.email, displayName: auth.currentUser.displayName, photoURL: auth.currentUser.photoURL }) : null;
onAuthStateChanged(auth, async user => {
  const previousUid = sessionStorage.getItem('jafn_cloud_uid') || '';
  currentUser = user;
  cloudReady = false;
  updateAuthUI(user);
  if (!user) {
    if (previousUid) {
      [...KEYS, CHAT_KEY].forEach(k => { try { localStorage.removeItem(k); } catch {} });
      sessionStorage.removeItem('jafn_cloud_uid');
      location.reload();
    }
    return;
  }
  try {
    cloudReady = true;
    await loadCloudState(user);
    cloudReady = true;
    sessionStorage.setItem('jafn_cloud_uid', user.uid);
    updateAuthUI(user);
    const marker = 'jafn_cloud_loaded_' + user.uid;
    if (sessionStorage.getItem(marker) !== 'yes') { sessionStorage.setItem(marker, 'yes'); location.reload(); return; }
  } catch (e) {
    cloudReady = false;
    console.error('Cloud data load failed', e);
    const status = document.getElementById('jafnAuthStatus'); if (status) status.textContent = '⚠️ Cloud belum siap';
    alert('Login berhasil, tetapi data cloud belum dapat dibaca. Periksa Firestore Database dan rules. Riwayat lokal belum dihapus.');
  }
});
window.addEventListener('beforeunload', () => { if (currentUser && cloudReady) { try { const value = localStorage.getItem(CHAT_KEY); if (value) syncChats(value); } catch {} } });
